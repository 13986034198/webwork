package model.vo;

public class Email {
	private String Email;

	/**
	 * @return the email
	 */
	public String getEmail() {
		return Email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		Email = email;
	}

	public Email(String email) {
		super();
		Email = email;
	}

	public Email() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
